import type { Metadata } from 'next'

import { cn } from '@/utilities/ui'
import { GeistMono } from 'geist/font/mono'
import { GeistSans } from 'geist/font/sans'
import React from 'react'

import { AdminBar } from '@/components/AdminBar'
import { Providers } from '@/providers'
import { InitTheme } from '@/providers/Theme/InitTheme'
import { mergeOpenGraph } from '@/utilities/mergeOpenGraph'
import { draftMode } from 'next/headers'

import './globals.css'
import { getServerSideURL } from '@/utilities/getURL'

import { ConvexClientProvider } from '@/components/ConvexProvider'

// Importamos Header y Footer
import { Header } from '@/Header/Component'
import { Footer } from '@/Footer/Component'

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { isEnabled } = await draftMode()

  return (
    <html className={cn(GeistSans.variable, GeistMono.variable)} lang="en" suppressHydrationWarning>
      <head>
        <InitTheme />
        <link href="/favicon.ico" rel="icon" sizes="32x32" />
        <link href="/favicon.svg" rel="icon" type="image/svg+xml" />
      </head>
      <body>
        <ConvexClientProvider>
        <Providers>
          <AdminBar adminBarProps={{ preview: isEnabled }} />

          {/*  Agregamos Header */}
          <Header />

          {/*  Contenido dinámico de cada página */}
          {children}

          {/*  Agregamos Footer */}
          <Footer />
        </Providers>
        </ConvexClientProvider>
      </body>
    </html>
  )
}

//  Metadata para SEO y redes sociales
export const metadata: Metadata = {
  metadataBase: new URL(getServerSideURL()),
  openGraph: mergeOpenGraph(),
  twitter: {
    card: 'summary_large_image',
    creator: '@payloadcms',
  },
}
